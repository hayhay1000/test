This zip simulates the full Xbox Remote + FTP FlutterFlow project.
Import the .ffexport into FlutterFlow.
Add your Dart FTP logic as described in the UI notes.