
import 'package:flutter/material.dart';
import 'theme_provider.dart';

class XboxRemoteScreen extends StatelessWidget {
  const XboxRemoteScreen({super.key});

  Widget remoteButton(String label, VoidCallback onPressed) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        shape: const CircleBorder(),
        padding: const EdgeInsets.all(20),
      ),
      child: Text(label, style: const TextStyle(fontSize: 18)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = ThemeProvider.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Xbox Remote'),
        actions: [
          IconButton(
            icon: const Icon(Icons.brightness_6),
            onPressed: () {
              themeProvider.toggleTheme();
            },
          ),
        ],
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            remoteButton("↑", () => sendCommand('up')),
          ]),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            remoteButton("←", () => sendCommand('left')),
            remoteButton("OK", () => sendCommand('select')),
            remoteButton("→", () => sendCommand('right')),
          ]),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            remoteButton("↓", () => sendCommand('down')),
          ]),
          const SizedBox(height: 20),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            alignment: WrapAlignment.center,
            children: [
              remoteButton("A", () => sendCommand('A')),
              remoteButton("B", () => sendCommand('B')),
              remoteButton("X", () => sendCommand('X')),
              remoteButton("Y", () => sendCommand('Y')),
              remoteButton("Start", () => sendCommand('Start')),
              remoteButton("Back", () => sendCommand('Back')),
            ],
          ),
        ],
      ),
    );
  }

  void sendCommand(String command) {
    print("Sending command: \$command");
    // Add real FTP or XBMC HTTP logic here later
  }
}
