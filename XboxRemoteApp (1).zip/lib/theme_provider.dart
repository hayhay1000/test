
import 'package:flutter/material.dart';

class ThemeProvider extends InheritedWidget {
  final _ThemeProviderState state;

  ThemeProvider({required Widget child, Key? key})
      : state = _ThemeProviderState(),
        super(key: key, child: child);

  static _ThemeProviderState of(BuildContext context) {
    return context.dependOnInheritedWidgetOfExactType<ThemeProvider>()!.state;
  }

  @override
  bool updateShouldNotify(covariant InheritedWidget oldWidget) => true;
}

class _ThemeProviderState {
  bool isDarkMode = false;

  void toggleTheme() {
    isDarkMode = !isDarkMode;
  }
}
