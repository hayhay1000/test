
import 'package:flutter/material.dart';
import 'theme_provider.dart';
import 'xbox_remote_screen.dart';

void main() {
  runApp(const XboxApp());
}

class XboxApp extends StatelessWidget {
  const XboxApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ThemeProvider(
      child: Builder(
        builder: (context) {
          final themeProvider = ThemeProvider.of(context);
          return MaterialApp(
            debugShowCheckedModeBanner: false,
            theme: themeProvider.isDarkMode ? ThemeData.dark() : ThemeData.light(),
            home: const XboxRemoteScreen(),
          );
        },
      ),
    );
  }
}
