function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-black text-white p-6">
      <header className="flex justify-between items-center py-4 border-b border-gray-700">
        <h1 className="text-2xl font-bold">Project Bolt</h1>
        <nav className="space-x-4">
          <a href="#" className="hover:underline">Home</a>
          <a href="#" className="hover:underline">About</a>
          <a href="#" className="hover:underline">Contact</a>
        </nav>
      </header>
      <main className="mt-16 text-center">
        <h2 className="text-4xl font-bold mb-4">Welcome to Project Bolt</h2>
        <p className="mb-6 text-lg text-gray-300">Your starting point for fast development with Vite + Tailwind.</p>
        <div className="space-x-4">
          <button className="bg-blue-600 hover:bg-blue-700 px-6 py-2 rounded text-white font-semibold">Get Started</button>
          <button className="bg-gray-700 hover:bg-gray-600 px-6 py-2 rounded text-white">Learn More</button>
        </div>
      </main>
    </div>
  );
}

export default App;
