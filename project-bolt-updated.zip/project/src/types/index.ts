export interface FileItem {
  name: string;
  type: 'file' | 'directory';
  size: number;
  modified: Date;
  path: string;
}

export interface XboxConnection {
  ip: string;
  username: string;
  password: string;
  port: number;
}

export interface TransferProgress {
  filename: string;
  progress: number;
  speed: string;
  eta: string;
}

export interface ConnectionStatus {
  connected: boolean;
  connecting: boolean;
  error: string | null;
}

export interface XboxStatus {
  temperature: number;
  cpuUsage: number;
  memoryUsage: number;
  diskSpace: {
    total: number;
    used: number;
    free: number;
  };
  uptime: string;
  currentGame: string | null;
}

export interface XboxControl {
  power: 'on' | 'off' | 'standby';
  dvdTray: 'open' | 'closed';
  currentApplication: string | null;
}