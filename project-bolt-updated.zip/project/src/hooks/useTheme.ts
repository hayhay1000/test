import { useState, useEffect } from 'react';

export type ThemeName = 
  | 'Dark (Default)'
  | 'Xbox Green'
  | 'Cyberpunk'
  | 'Ocean Blue'
  | 'Sunset Orange'
  | 'Light Mode';

interface ThemeConfig {
  name: ThemeName;
  colors: {
    primary: string;
    secondary: string;
    accent: string;
    background: string;
    surface: string;
    text: string;
    textSecondary: string;
    border: string;
    success: string;
    warning: string;
    error: string;
  };
  classes: {
    background: string;
    surface: string;
    surfaceHover: string;
    text: string;
    textSecondary: string;
    border: string;
    primary: string;
    primaryHover: string;
    accent: string;
    success: string;
    warning: string;
    error: string;
  };
}

const themes: Record<ThemeName, ThemeConfig> = {
  'Dark (Default)': {
    name: 'Dark (Default)',
    colors: {
      primary: '#3B82F6',
      secondary: '#6B7280',
      accent: '#10B981',
      background: '#111827',
      surface: '#1F2937',
      text: '#FFFFFF',
      textSecondary: '#9CA3AF',
      border: '#374151',
      success: '#10B981',
      warning: '#F59E0B',
      error: '#EF4444'
    },
    classes: {
      background: 'bg-gray-900',
      surface: 'bg-gray-800',
      surfaceHover: 'hover:bg-gray-700',
      text: 'text-white',
      textSecondary: 'text-gray-400',
      border: 'border-gray-700',
      primary: 'bg-blue-600',
      primaryHover: 'hover:bg-blue-700',
      accent: 'bg-green-600',
      success: 'bg-green-600',
      warning: 'bg-yellow-600',
      error: 'bg-red-600'
    }
  },
  'Xbox Green': {
    name: 'Xbox Green',
    colors: {
      primary: '#10B981',
      secondary: '#6B7280',
      accent: '#84CC16',
      background: '#0F1419',
      surface: '#1A2332',
      text: '#FFFFFF',
      textSecondary: '#9CA3AF',
      border: '#2D3748',
      success: '#10B981',
      warning: '#F59E0B',
      error: '#EF4444'
    },
    classes: {
      background: 'bg-gray-900',
      surface: 'bg-slate-800',
      surfaceHover: 'hover:bg-slate-700',
      text: 'text-white',
      textSecondary: 'text-gray-400',
      border: 'border-slate-600',
      primary: 'bg-green-600',
      primaryHover: 'hover:bg-green-700',
      accent: 'bg-lime-500',
      success: 'bg-green-600',
      warning: 'bg-yellow-600',
      error: 'bg-red-600'
    }
  },
  'Cyberpunk': {
    name: 'Cyberpunk',
    colors: {
      primary: '#8B5CF6',
      secondary: '#EC4899',
      accent: '#06B6D4',
      background: '#0C0A1A',
      surface: '#1A1625',
      text: '#FFFFFF',
      textSecondary: '#A78BFA',
      border: '#2D1B69',
      success: '#10B981',
      warning: '#F59E0B',
      error: '#EF4444'
    },
    classes: {
      background: 'bg-purple-950',
      surface: 'bg-purple-900',
      surfaceHover: 'hover:bg-purple-800',
      text: 'text-white',
      textSecondary: 'text-purple-300',
      border: 'border-purple-700',
      primary: 'bg-purple-600',
      primaryHover: 'hover:bg-purple-700',
      accent: 'bg-cyan-500',
      success: 'bg-green-600',
      warning: 'bg-yellow-600',
      error: 'bg-red-600'
    }
  },
  'Ocean Blue': {
    name: 'Ocean Blue',
    colors: {
      primary: '#3B82F6',
      secondary: '#64748B',
      accent: '#14B8A6',
      background: '#0F172A',
      surface: '#1E293B',
      text: '#FFFFFF',
      textSecondary: '#94A3B8',
      border: '#334155',
      success: '#10B981',
      warning: '#F59E0B',
      error: '#EF4444'
    },
    classes: {
      background: 'bg-slate-900',
      surface: 'bg-slate-800',
      surfaceHover: 'hover:bg-slate-700',
      text: 'text-white',
      textSecondary: 'text-slate-400',
      border: 'border-slate-600',
      primary: 'bg-blue-600',
      primaryHover: 'hover:bg-blue-700',
      accent: 'bg-teal-500',
      success: 'bg-green-600',
      warning: 'bg-yellow-600',
      error: 'bg-red-600'
    }
  },
  'Sunset Orange': {
    name: 'Sunset Orange',
    colors: {
      primary: '#EA580C',
      secondary: '#DC2626',
      accent: '#EAB308',
      background: '#1A0F0A',
      surface: '#2D1B13',
      text: '#FFFFFF',
      textSecondary: '#FDBA74',
      border: '#451A03',
      success: '#10B981',
      warning: '#F59E0B',
      error: '#EF4444'
    },
    classes: {
      background: 'bg-orange-950',
      surface: 'bg-orange-900',
      surfaceHover: 'hover:bg-orange-800',
      text: 'text-white',
      textSecondary: 'text-orange-300',
      border: 'border-orange-700',
      primary: 'bg-orange-600',
      primaryHover: 'hover:bg-orange-700',
      accent: 'bg-yellow-500',
      success: 'bg-green-600',
      warning: 'bg-yellow-600',
      error: 'bg-red-600'
    }
  },
  'Light Mode': {
    name: 'Light Mode',
    colors: {
      primary: '#3B82F6',
      secondary: '#6B7280',
      accent: '#10B981',
      background: '#F9FAFB',
      surface: '#FFFFFF',
      text: '#111827',
      textSecondary: '#6B7280',
      border: '#E5E7EB',
      success: '#10B981',
      warning: '#F59E0B',
      error: '#EF4444'
    },
    classes: {
      background: 'bg-gray-50',
      surface: 'bg-white',
      surfaceHover: 'hover:bg-gray-100',
      text: 'text-gray-900',
      textSecondary: 'text-gray-600',
      border: 'border-gray-300',
      primary: 'bg-blue-600',
      primaryHover: 'hover:bg-blue-700',
      accent: 'bg-green-600',
      success: 'bg-green-600',
      warning: 'bg-yellow-600',
      error: 'bg-red-600'
    }
  }
};

export const useTheme = () => {
  const [currentTheme, setCurrentTheme] = useState<ThemeName>('Dark (Default)');

  useEffect(() => {
    // Load theme from localStorage on mount
    const savedTheme = localStorage.getItem('xbox-manager-theme') as ThemeName;
    if (savedTheme && themes[savedTheme]) {
      setCurrentTheme(savedTheme);
    }
  }, []);

  const changeTheme = (themeName: ThemeName) => {
    setCurrentTheme(themeName);
    localStorage.setItem('xbox-manager-theme', themeName);
  };

  const theme = themes[currentTheme];

  return {
    currentTheme,
    theme,
    changeTheme,
    availableThemes: Object.keys(themes) as ThemeName[]
  };
};