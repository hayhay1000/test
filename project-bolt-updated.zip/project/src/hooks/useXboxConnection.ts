
import { useState, useCallback } from 'react';
import { XboxConnection, ConnectionStatus, FileItem } from '../types';
import { listXboxFiles } from '../lib/ftpClient';

export const useXboxConnection = () => {
  const [connection, setConnection] = useState<XboxConnection>({
    ip: '',
    username: 'xbox',
    password: 'xbox',
    port: 21,
  });

  const [status, setStatus] = useState<ConnectionStatus>({
    connected: false,
    connecting: false,
    error: null,
  });

  const [xboxFiles, setXboxFiles] = useState<FileItem[]>([]);
  const [xboxPath, setXboxPath] = useState('/');

  const connect = useCallback(async () => {
    setStatus({ ...status, connecting: true });
    try {
      const files = await listXboxFiles('/');
      setXboxFiles(files.map(f => ({
        name: f.name,
        type: f.isDirectory ? 'directory' : 'file',
        size: f.size,
        modified: new Date(f.rawModifiedAt || Date.now()),
        path: '/' + f.name
      })));
      setXboxPath('/');
      setStatus({ connected: true, connecting: false, error: null });
    } catch (err) {
      setStatus({ connected: false, connecting: false, error: 'Failed to connect to Xbox FTP' });
    }
  }, [status]);

  const disconnect = useCallback(() => {
    setStatus({ connected: false, connecting: false, error: null });
    setXboxFiles([]);
    setXboxPath('/');
  }, []);

  const navigateXbox = useCallback(async (newPath: string) => {
    try {
      const files = await listXboxFiles(newPath);
      setXboxFiles(files.map(f => ({
        name: f.name,
        type: f.isDirectory ? 'directory' : 'file',
        size: f.size,
        modified: new Date(f.rawModifiedAt || Date.now()),
        path: newPath + '/' + f.name
      })));
      setXboxPath(newPath);
    } catch (err) {
      console.error('Navigation failed:', err);
    }
  }, []);

  return {
    connection,
    setConnection,
    status,
    xboxFiles,
    xboxPath,
    connect,
    disconnect,
    navigateXbox,
  };
};
