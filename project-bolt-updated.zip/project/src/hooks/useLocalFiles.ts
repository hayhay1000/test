import { useState, useCallback } from 'react';
import { FileItem } from '../types';

export const useLocalFiles = () => {
  const [localFiles, setLocalFiles] = useState<FileItem[]>([]);
  const [localPath, setLocalPath] = useState('/home/user');

  // Mock local files for demonstration
  const mockLocalFiles: FileItem[] = [
    {
      name: 'Documents',
      type: 'directory',
      size: 0,
      modified: new Date(),
      path: '/home/user/Documents',
    },
    {
      name: 'Downloads',
      type: 'directory',
      size: 0,
      modified: new Date(),
      path: '/home/user/Downloads',
    },
    {
      name: 'Desktop',
      type: 'directory',
      size: 0,
      modified: new Date(),
      path: '/home/user/Desktop',
    },
    {
      name: 'game_backup.iso',
      type: 'file',
      size: 734003200,
      modified: new Date(),
      path: '/home/user/game_backup.iso',
    },
    {
      name: 'readme.txt',
      type: 'file',
      size: 2048,
      modified: new Date(),
      path: '/home/user/readme.txt',
    },
  ];

  useState(() => {
    setLocalFiles(mockLocalFiles);
  });

  const navigateLocal = useCallback(async (path: string) => {
    // Mock navigation
    const mockSubFiles: FileItem[] = [
      {
        name: 'subfolder',
        type: 'directory',
        size: 0,
        modified: new Date(),
        path: path + '/subfolder',
      },
      {
        name: 'document.pdf',
        type: 'file',
        size: 1048576,
        modified: new Date(),
        path: path + '/document.pdf',
      },
    ];

    setLocalPath(path);
    setLocalFiles(path === '/home/user' ? mockLocalFiles : mockSubFiles);
  }, [mockLocalFiles]);

  return {
    localFiles,
    localPath,
    navigateLocal,
  };
};