import React, { useState, useEffect } from 'react';
import { 
  Power, 
  RotateCcw, 
  Disc, 
  Play, 
  Pause, 
  Square, 
  Volume2, 
  VolumeX,
  Thermometer,
  Cpu,
  HardDrive,
  Clock,
  Gamepad2,
  Monitor,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { XboxStatus, XboxControl } from '../types';

interface XboxControlPanelProps {
  isConnected: boolean;
  onPowerControl: (action: 'power' | 'restart' | 'shutdown') => void;
  onMediaControl: (action: 'play' | 'pause' | 'stop' | 'eject') => void;
  onVolumeControl: (action: 'mute' | 'unmute' | 'volumeUp' | 'volumeDown') => void;
  theme: any;
}

export const XboxControlPanel: React.FC<XboxControlPanelProps> = ({
  isConnected,
  onPowerControl,
  onMediaControl,
  onVolumeControl,
  theme,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [xboxStatus, setXboxStatus] = useState<XboxStatus>({
    temperature: 45,
    cpuUsage: 23,
    memoryUsage: 67,
    diskSpace: {
      total: 8589934592, // 8GB
      used: 5368709120, // 5GB
      free: 3221225472, // 3GB
    },
    uptime: '2h 34m',
    currentGame: 'Halo 2',
  });

  const [xboxControl, setXboxControl] = useState<XboxControl>({
    power: 'on',
    dvdTray: 'closed',
    currentApplication: 'Dashboard',
  });

  const [isMuted, setIsMuted] = useState(false);

  // Mock status updates
  useEffect(() => {
    if (!isConnected) return;

    const interval = setInterval(() => {
      setXboxStatus(prev => ({
        ...prev,
        temperature: 40 + Math.random() * 20,
        cpuUsage: Math.random() * 100,
        memoryUsage: 50 + Math.random() * 40,
      }));
    }, 3000);

    return () => clearInterval(interval);
  }, [isConnected]);

  const formatBytes = (bytes: number): string => {
    const gb = bytes / (1024 * 1024 * 1024);
    return `${gb.toFixed(1)} GB`;
  };

  const getTemperatureColor = (temp: number): string => {
    if (temp > 60) return 'text-red-400';
    if (temp > 50) return 'text-yellow-400';
    return 'text-green-400';
  };

  const handlePowerAction = (action: 'power' | 'restart' | 'shutdown') => {
    onPowerControl(action);
    if (action === 'shutdown') {
      setXboxControl(prev => ({ ...prev, power: 'off' }));
    } else if (action === 'power') {
      setXboxControl(prev => ({ 
        ...prev, 
        power: prev.power === 'off' ? 'on' : 'off' 
      }));
    }
  };

  const handleMediaAction = (action: 'play' | 'pause' | 'stop' | 'eject') => {
    onMediaControl(action);
    if (action === 'eject') {
      setXboxControl(prev => ({ 
        ...prev, 
        dvdTray: prev.dvdTray === 'closed' ? 'open' : 'closed' 
      }));
    }
  };

  const handleVolumeAction = (action: 'mute' | 'unmute' | 'volumeUp' | 'volumeDown') => {
    onVolumeControl(action);
    if (action === 'mute' || action === 'unmute') {
      setIsMuted(action === 'mute');
    }
  };

  if (!isConnected) {
    return (
      <div className={`${theme.classes.surface} border ${theme.classes.border} rounded-lg p-4`}>
        <div className={`flex items-center justify-center h-32 ${theme.classes.textSecondary}`}>
          <div className="text-center">
            <Gamepad2 className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <p>Connect to Xbox to access controls</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`${theme.classes.surface} border ${theme.classes.border} rounded-lg overflow-hidden`}>
      {/* Header */}
      <div 
        className={`${theme.classes.background} border-b ${theme.classes.border} p-4 cursor-pointer ${theme.classes.surfaceHover} transition-colors`}
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Gamepad2 className="w-5 h-5 text-green-400" />
            <h3 className={`${theme.classes.text} font-semibold`}>Xbox Control Panel</h3>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="text-green-400 text-sm font-medium">Online</span>
            </div>
          </div>
          {isExpanded ? (
            <ChevronUp className={`w-5 h-5 ${theme.classes.textSecondary}`} />
          ) : (
            <ChevronDown className={`w-5 h-5 ${theme.classes.textSecondary}`} />
          )}
        </div>
      </div>

      {isExpanded && (
        <div className="p-4 space-y-6">
          {/* System Status */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className={`${theme.classes.background} rounded-lg p-3`}>
              <div className="flex items-center space-x-2 mb-1">
                <Thermometer className={`w-4 h-4 ${getTemperatureColor(xboxStatus.temperature)}`} />
                <span className={`${theme.classes.textSecondary} text-sm`}>Temperature</span>
              </div>
              <p className={`text-lg font-semibold ${getTemperatureColor(xboxStatus.temperature)}`}>
                {xboxStatus.temperature.toFixed(1)}°C
              </p>
            </div>

            <div className={`${theme.classes.background} rounded-lg p-3`}>
              <div className="flex items-center space-x-2 mb-1">
                <Cpu className="w-4 h-4 text-blue-400" />
                <span className={`${theme.classes.textSecondary} text-sm`}>CPU Usage</span>
              </div>
              <p className="text-lg font-semibold text-blue-400">
                {xboxStatus.cpuUsage.toFixed(0)}%
              </p>
            </div>

            <div className={`${theme.classes.background} rounded-lg p-3`}>
              <div className="flex items-center space-x-2 mb-1">
                <Monitor className="w-4 h-4 text-purple-400" />
                <span className={`${theme.classes.textSecondary} text-sm`}>Memory</span>
              </div>
              <p className="text-lg font-semibold text-purple-400">
                {xboxStatus.memoryUsage.toFixed(0)}%
              </p>
            </div>

            <div className={`${theme.classes.background} rounded-lg p-3`}>
              <div className="flex items-center space-x-2 mb-1">
                <Clock className="w-4 h-4 text-yellow-400" />
                <span className={`${theme.classes.textSecondary} text-sm`}>Uptime</span>
              </div>
              <p className="text-lg font-semibold text-yellow-400">
                {xboxStatus.uptime}
              </p>
            </div>
          </div>

          {/* Storage Info */}
          <div className={`${theme.classes.background} rounded-lg p-4`}>
            <div className="flex items-center space-x-2 mb-3">
              <HardDrive className={`w-4 h-4 ${theme.classes.textSecondary}`} />
              <span className={`${theme.classes.text} font-medium`}>Storage</span>
            </div>
            <div className="space-y-2">
              <div className={`flex justify-between text-sm`}>
                <span className={theme.classes.textSecondary}>Used: {formatBytes(xboxStatus.diskSpace.used)}</span>
                <span className={theme.classes.textSecondary}>Free: {formatBytes(xboxStatus.diskSpace.free)}</span>
              </div>
              <div className="w-full bg-gray-600 rounded-full h-2">
                <div
                  className="bg-blue-500 h-2 rounded-full transition-all duration-300"
                  style={{ 
                    width: `${(xboxStatus.diskSpace.used / xboxStatus.diskSpace.total) * 100}%` 
                  }}
                />
              </div>
            </div>
          </div>

          {/* Current Game/App */}
          {xboxStatus.currentGame && (
            <div className={`${theme.classes.background} rounded-lg p-4`}>
              <div className="flex items-center space-x-2 mb-2">
                <Disc className="w-4 h-4 text-green-400" />
                <span className={`${theme.classes.text} font-medium`}>Currently Playing</span>
              </div>
              <p className="text-green-400 font-semibold">{xboxStatus.currentGame}</p>
            </div>
          )}

          {/* Power Controls */}
          <div className="space-y-3">
            <h4 className={`${theme.classes.text} font-medium`}>Power Controls</h4>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => handlePowerAction('power')}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                  xboxControl.power === 'on'
                    ? 'bg-green-600 hover:bg-green-700 text-white'
                    : 'bg-gray-600 hover:bg-gray-700 text-gray-300'
                }`}
              >
                <Power className="w-4 h-4" />
                <span>{xboxControl.power === 'on' ? 'Power Off' : 'Power On'}</span>
              </button>

              <button
                onClick={() => handlePowerAction('restart')}
                className="flex items-center space-x-2 px-4 py-2 bg-yellow-600 hover:bg-yellow-700 text-white rounded-lg font-medium transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Restart</span>
              </button>

              <button
                onClick={() => handlePowerAction('shutdown')}
                className="flex items-center space-x-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-medium transition-colors"
              >
                <Power className="w-4 h-4" />
                <span>Shutdown</span>
              </button>
            </div>
          </div>

          {/* Media Controls */}
          <div className="space-y-3">
            <h4 className={`${theme.classes.text} font-medium`}>Media Controls</h4>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => handleMediaAction('play')}
                className="flex items-center space-x-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors"
              >
                <Play className="w-4 h-4" />
                <span>Play</span>
              </button>

              <button
                onClick={() => handleMediaAction('pause')}
                className="flex items-center space-x-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors"
              >
                <Pause className="w-4 h-4" />
                <span>Pause</span>
              </button>

              <button
                onClick={() => handleMediaAction('stop')}
                className="flex items-center space-x-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors"
              >
                <Square className="w-4 h-4" />
                <span>Stop</span>
              </button>

              <button
                onClick={() => handleMediaAction('eject')}
                className="flex items-center space-x-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-medium transition-colors"
              >
                <Disc className="w-4 h-4" />
                <span>{xboxControl.dvdTray === 'closed' ? 'Eject' : 'Close'} Tray</span>
              </button>
            </div>
          </div>

          {/* Volume Controls */}
          <div className="space-y-3">
            <h4 className={`${theme.classes.text} font-medium`}>Audio Controls</h4>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => handleVolumeAction(isMuted ? 'unmute' : 'mute')}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                  isMuted
                    ? 'bg-red-600 hover:bg-red-700 text-white'
                    : 'bg-gray-600 hover:bg-gray-700 text-white'
                }`}
              >
                {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                <span>{isMuted ? 'Unmute' : 'Mute'}</span>
              </button>

              <button
                onClick={() => handleVolumeAction('volumeUp')}
                className="flex items-center space-x-2 px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg font-medium transition-colors"
              >
                <Volume2 className="w-4 h-4" />
                <span>Volume +</span>
              </button>

              <button
                onClick={() => handleVolumeAction('volumeDown')}
                className="flex items-center space-x-2 px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg font-medium transition-colors"
              >
                <Volume2 className="w-4 h-4" />
                <span>Volume -</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};