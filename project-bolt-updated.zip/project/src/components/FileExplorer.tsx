
import React, { useState, useRef } from 'react';
import {
  Folder,
  File,
  ChevronUp,
  Download,
  Upload,
  Trash2,
  MoreHorizontal,
} from 'lucide-react';
import { FileItem } from '../types';

interface FileExplorerProps {
  title: string;
  files: FileItem[];
  currentPath: string;
  onNavigate: (path: string) => void;
  onFileSelect: (file: FileItem) => void;
  onFileAction: (action: string, file: FileItem | File | null) => void;
  selectedFiles: FileItem[];
  isXbox?: boolean;
  theme: any;
}

export const FileExplorer: React.FC<FileExplorerProps> = ({
  title,
  files,
  currentPath,
  onNavigate,
  onFileSelect,
  onFileAction,
  selectedFiles,
  isXbox = false,
  theme,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleUploadClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onFileAction('upload', file);
    }
  };

  return (
    <div className="rounded-xl border bg-muted text-muted-foreground shadow-lg w-full max-w-4xl p-4">
      <h2 className="text-xl font-bold mb-4">{title}</h2>
      <div className="flex gap-2 mb-2">
        <button className="btn" onClick={handleUploadClick}>
          <Upload className="w-4 h-4 mr-1" /> Upload
        </button>
        <input
          ref={fileInputRef}
          type="file"
          className="hidden"
          onChange={handleFileChange}
        />
        {selectedFiles.length > 0 && (
          <>
            <button
              className="btn"
              onClick={() => onFileAction('download', selectedFiles[0])}
            >
              <Download className="w-4 h-4 mr-1" /> Download
            </button>
            <button
              className="btn"
              onClick={() => onFileAction('delete', selectedFiles[0])}
            >
              <Trash2 className="w-4 h-4 mr-1" /> Delete
            </button>
          </>
        )}
      </div>
      <ul className="space-y-2">
        {files.map((file) => (
          <li
            key={file.name}
            className="flex items-center gap-2 cursor-pointer hover:bg-accent p-2 rounded-md"
            onClick={() =>
              file.type === 'directory'
                ? onNavigate(file.path)
                : onFileSelect(file)
            }
          >
            {file.type === 'directory' ? (
              <Folder className="w-5 h-5" />
            ) : (
              <File className="w-5 h-5" />
            )}
            <span>{file.name}</span>
            <span className="ml-auto text-xs">
              {file.type === 'file' && formatFileSize(file.size)}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
};
