import React from 'react';
import { Download, Upload, X, Pause, Play } from 'lucide-react';
import { TransferProgress } from '../types';

interface TransferPanelProps {
  transfers: TransferProgress[];
  onCancelTransfer: (filename: string) => void;
  onPauseTransfer: (filename: string) => void;
  onResumeTransfer: (filename: string) => void;
  theme: any;
}

export const TransferPanel: React.FC<TransferPanelProps> = ({
  transfers,
  onCancelTransfer,
  onPauseTransfer,
  onResumeTransfer,
  theme,
}) => {
  if (transfers.length === 0) return null;

  return (
    <div className={`${theme.classes.background} border-t ${theme.classes.border} p-4`}>
      <h3 className={`${theme.classes.text} font-medium mb-3`}>File Transfers</h3>
      <div className="space-y-2">
        {transfers.map((transfer, index) => (
          <div key={index} className={`${theme.classes.surface} rounded-lg p-3`}>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2">
                <Download className="w-4 h-4 text-blue-400" />
                <span className={`${theme.classes.text} text-sm font-medium truncate`}>
                  {transfer.filename}
                </span>
              </div>
              <div className="flex items-center space-x-1">
                <button
                  onClick={() => onPauseTransfer(transfer.filename)}
                  className={`p-1 ${theme.classes.textSecondary} hover:${theme.classes.text} ${theme.classes.surfaceHover} rounded transition-colors`}
                >
                  <Pause className="w-3 h-3" />
                </button>
                <button
                  onClick={() => onCancelTransfer(transfer.filename)}
                  className={`p-1 ${theme.classes.textSecondary} hover:text-red-400 ${theme.classes.surfaceHover} rounded transition-colors`}
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            </div>
            
            <div className="mb-2">
              <div className={`w-full bg-gray-700 rounded-full h-2`}>
                <div
                  className="bg-blue-500 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${transfer.progress}%` }}
                />
              </div>
            </div>
            
            <div className={`flex justify-between text-xs ${theme.classes.textSecondary}`}>
              <span>{transfer.progress.toFixed(1)}%</span>
              <span>{transfer.speed}</span>
              <span>ETA: {transfer.eta}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};