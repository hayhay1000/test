import React, { useState } from 'react';
import { 
  Settings, 
  Palette, 
  Monitor, 
  Sun, 
  Moon, 
  Contrast,
  Eye,
  Volume2,
  Wifi,
  HardDrive,
  Save,
  RotateCcw,
  X
} from 'lucide-react';
import { ThemeName } from '../hooks/useTheme';

interface Theme {
  name: ThemeName;
  primary: string;
  secondary: string;
  accent: string;
  background: string;
  surface: string;
  text: string;
  preview: {
    bg: string;
    surface: string;
    primary: string;
    text: string;
    accent: string;
  };
}

interface SettingsPanelProps {
  isOpen: boolean;
  onClose: () => void;
  currentTheme: ThemeName;
  onThemeChange: (theme: ThemeName) => void;
}

export const SettingsPanel: React.FC<SettingsPanelProps> = ({
  isOpen,
  onClose,
  currentTheme,
  onThemeChange,
}) => {
  const [activeTab, setActiveTab] = useState<'appearance' | 'connection' | 'performance' | 'audio'>('appearance');
  
  const themes: Theme[] = [
    {
      name: 'Dark (Default)',
      primary: 'blue',
      secondary: 'gray',
      accent: 'green',
      background: 'gray-900',
      surface: 'gray-800',
      text: 'white',
      preview: {
        bg: 'bg-gray-900',
        surface: 'bg-gray-800',
        primary: 'bg-blue-600',
        text: 'text-white',
        accent: 'bg-green-500'
      }
    },
    {
      name: 'Xbox Green',
      primary: 'green',
      secondary: 'gray',
      accent: 'lime',
      background: 'gray-900',
      surface: 'slate-800',
      text: 'white',
      preview: {
        bg: 'bg-gray-900',
        surface: 'bg-slate-800',
        primary: 'bg-green-600',
        text: 'text-white',
        accent: 'bg-lime-500'
      }
    },
    {
      name: 'Cyberpunk',
      primary: 'purple',
      secondary: 'pink',
      accent: 'cyan',
      background: 'purple-950',
      surface: 'purple-900',
      text: 'white',
      preview: {
        bg: 'bg-purple-950',
        surface: 'bg-purple-900',
        primary: 'bg-purple-600',
        text: 'text-white',
        accent: 'bg-cyan-500'
      }
    },
    {
      name: 'Ocean Blue',
      primary: 'blue',
      secondary: 'slate',
      accent: 'teal',
      background: 'slate-900',
      surface: 'slate-800',
      text: 'white',
      preview: {
        bg: 'bg-slate-900',
        surface: 'bg-slate-800',
        primary: 'bg-blue-600',
        text: 'text-white',
        accent: 'bg-teal-500'
      }
    },
    {
      name: 'Sunset Orange',
      primary: 'orange',
      secondary: 'red',
      accent: 'yellow',
      background: 'orange-950',
      surface: 'orange-900',
      text: 'white',
      preview: {
        bg: 'bg-orange-950',
        surface: 'bg-orange-900',
        primary: 'bg-orange-600',
        text: 'text-white',
        accent: 'bg-yellow-500'
      }
    },
    {
      name: 'Light Mode',
      primary: 'blue',
      secondary: 'gray',
      accent: 'green',
      background: 'gray-50',
      surface: 'white',
      text: 'gray-900',
      preview: {
        bg: 'bg-gray-50',
        surface: 'bg-white',
        primary: 'bg-blue-600',
        text: 'text-gray-900',
        accent: 'bg-green-600'
      }
    }
  ];

  const [settings, setSettings] = useState({
    // Appearance
    fontSize: 'medium',
    compactMode: false,
    showAnimations: true,
    highContrast: false,
    
    // Connection
    autoReconnect: true,
    connectionTimeout: 30,
    maxRetries: 3,
    
    // Performance
    enableCaching: true,
    maxCacheSize: 100,
    preloadThumbnails: true,
    
    // Audio
    soundEffects: true,
    notificationSounds: true,
    volume: 75
  });

  const handleSettingChange = (key: string, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const resetToDefaults = () => {
    setSettings({
      fontSize: 'medium',
      compactMode: false,
      showAnimations: true,
      highContrast: false,
      autoReconnect: true,
      connectionTimeout: 30,
      maxRetries: 3,
      enableCaching: true,
      maxCacheSize: 100,
      preloadThumbnails: true,
      soundEffects: true,
      notificationSounds: true,
      volume: 75
    });
    onThemeChange('Dark (Default)');
  };

  const saveSettings = () => {
    // In a real app, this would save to localStorage or a backend
    console.log('Settings saved:', settings);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-gray-800 border border-gray-700 rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="bg-gray-900 border-b border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Settings className="w-6 h-6 text-blue-400" />
              <h2 className="text-xl font-semibold text-white">Settings</h2>
            </div>
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="flex h-[calc(90vh-120px)]">
          {/* Sidebar */}
          <div className="w-64 bg-gray-900 border-r border-gray-700 p-4">
            <nav className="space-y-2">
              {[
                { id: 'appearance', label: 'Appearance', icon: Palette },
                { id: 'connection', label: 'Connection', icon: Wifi },
                { id: 'performance', label: 'Performance', icon: HardDrive },
                { id: 'audio', label: 'Audio', icon: Volume2 }
              ].map(({ id, label, icon: Icon }) => (
                <button
                  key={id}
                  onClick={() => setActiveTab(id as any)}
                  className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors ${
                    activeTab === id
                      ? 'bg-blue-600 text-white'
                      : 'text-gray-300 hover:text-white hover:bg-gray-700'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{label}</span>
                </button>
              ))}
            </nav>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto p-6">
            {activeTab === 'appearance' && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold text-white mb-4">Theme Selection</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {themes.map((theme) => (
                      <div
                        key={theme.name}
                        className={`relative cursor-pointer rounded-lg border-2 transition-all ${
                          currentTheme === theme.name
                            ? 'border-blue-500 ring-2 ring-blue-500/20'
                            : 'border-gray-600 hover:border-gray-500'
                        }`}
                        onClick={() => onThemeChange(theme.name)}
                      >
                        <div className={`${theme.preview.bg} p-4 rounded-t-lg`}>
                          <div className={`${theme.preview.surface} p-3 rounded-lg mb-2`}>
                            <div className={`${theme.preview.primary} h-2 w-16 rounded mb-2`}></div>
                            <div className={`${theme.preview.accent} h-1 w-12 rounded mb-1`}></div>
                            <div className={`${theme.preview.text} opacity-60`}>
                              <div className="h-1 w-full bg-current opacity-40 rounded mb-1"></div>
                              <div className="h-1 w-3/4 bg-current opacity-40 rounded"></div>
                            </div>
                          </div>
                        </div>
                        <div className="p-3 bg-gray-700">
                          <p className="text-white font-medium text-sm">{theme.name}</p>
                        </div>
                        {currentTheme === theme.name && (
                          <div className="absolute top-2 right-2 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
                            <div className="w-2 h-2 bg-white rounded-full"></div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-white">Display Options</h3>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="block text-gray-300 text-sm font-medium mb-2">
                        Font Size
                      </label>
                      <select
                        value={settings.fontSize}
                        onChange={(e) => handleSettingChange('fontSize', e.target.value)}
                        className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="small">Small</option>
                        <option value="medium">Medium</option>
                        <option value="large">Large</option>
                        <option value="extra-large">Extra Large</option>
                      </select>
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <label className="text-gray-300 font-medium">Compact Mode</label>
                        <p className="text-gray-400 text-sm">Reduce spacing and padding</p>
                      </div>
                      <button
                        onClick={() => handleSettingChange('compactMode', !settings.compactMode)}
                        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                          settings.compactMode ? 'bg-blue-600' : 'bg-gray-600'
                        }`}
                      >
                        <span
                          className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                            settings.compactMode ? 'translate-x-6' : 'translate-x-1'
                          }`}
                        />
                      </button>
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <label className="text-gray-300 font-medium">Animations</label>
                        <p className="text-gray-400 text-sm">Enable smooth transitions and effects</p>
                      </div>
                      <button
                        onClick={() => handleSettingChange('showAnimations', !settings.showAnimations)}
                        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                          settings.showAnimations ? 'bg-blue-600' : 'bg-gray-600'
                        }`}
                      >
                        <span
                          className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                            settings.showAnimations ? 'translate-x-6' : 'translate-x-1'
                          }`}
                        />
                      </button>
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <label className="text-gray-300 font-medium">High Contrast</label>
                        <p className="text-gray-400 text-sm">Increase contrast for better visibility</p>
                      </div>
                      <button
                        onClick={() => handleSettingChange('highContrast', !settings.highContrast)}
                        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                          settings.highContrast ? 'bg-blue-600' : 'bg-gray-600'
                        }`}
                      >
                        <span
                          className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                            settings.highContrast ? 'translate-x-6' : 'translate-x-1'
                          }`}
                        />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'connection' && (
              <div className="space-y-6">
                <h3 className="text-lg font-semibold text-white">Connection Settings</h3>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <label className="text-gray-300 font-medium">Auto Reconnect</label>
                      <p className="text-gray-400 text-sm">Automatically reconnect when connection is lost</p>
                    </div>
                    <button
                      onClick={() => handleSettingChange('autoReconnect', !settings.autoReconnect)}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                        settings.autoReconnect ? 'bg-blue-600' : 'bg-gray-600'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          settings.autoReconnect ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>

                  <div>
                    <label className="block text-gray-300 text-sm font-medium mb-2">
                      Connection Timeout (seconds)
                    </label>
                    <input
                      type="number"
                      min="5"
                      max="120"
                      value={settings.connectionTimeout}
                      onChange={(e) => handleSettingChange('connectionTimeout', parseInt(e.target.value))}
                      className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-gray-300 text-sm font-medium mb-2">
                      Max Retry Attempts
                    </label>
                    <input
                      type="number"
                      min="1"
                      max="10"
                      value={settings.maxRetries}
                      onChange={(e) => handleSettingChange('maxRetries', parseInt(e.target.value))}
                      className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'performance' && (
              <div className="space-y-6">
                <h3 className="text-lg font-semibold text-white">Performance Settings</h3>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <label className="text-gray-300 font-medium">Enable Caching</label>
                      <p className="text-gray-400 text-sm">Cache file listings for faster navigation</p>
                    </div>
                    <button
                      onClick={() => handleSettingChange('enableCaching', !settings.enableCaching)}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                        settings.enableCaching ? 'bg-blue-600' : 'bg-gray-600'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          settings.enableCaching ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>

                  <div>
                    <label className="block text-gray-300 text-sm font-medium mb-2">
                      Max Cache Size (MB)
                    </label>
                    <input
                      type="number"
                      min="10"
                      max="1000"
                      value={settings.maxCacheSize}
                      onChange={(e) => handleSettingChange('maxCacheSize', parseInt(e.target.value))}
                      className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <label className="text-gray-300 font-medium">Preload Thumbnails</label>
                      <p className="text-gray-400 text-sm">Generate thumbnails for image files</p>
                    </div>
                    <button
                      onClick={() => handleSettingChange('preloadThumbnails', !settings.preloadThumbnails)}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                        settings.preloadThumbnails ? 'bg-blue-600' : 'bg-gray-600'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          settings.preloadThumbnails ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'audio' && (
              <div className="space-y-6">
                <h3 className="text-lg font-semibold text-white">Audio Settings</h3>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <label className="text-gray-300 font-medium">Sound Effects</label>
                      <p className="text-gray-400 text-sm">Play sounds for UI interactions</p>
                    </div>
                    <button
                      onClick={() => handleSettingChange('soundEffects', !settings.soundEffects)}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                        settings.soundEffects ? 'bg-blue-600' : 'bg-gray-600'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          settings.soundEffects ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <label className="text-gray-300 font-medium">Notification Sounds</label>
                      <p className="text-gray-400 text-sm">Play sounds for transfer completion and errors</p>
                    </div>
                    <button
                      onClick={() => handleSettingChange('notificationSounds', !settings.notificationSounds)}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                        settings.notificationSounds ? 'bg-blue-600' : 'bg-gray-600'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          settings.notificationSounds ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>

                  <div>
                    <label className="block text-gray-300 text-sm font-medium mb-2">
                      Volume Level: {settings.volume}%
                    </label>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={settings.volume}
                      onChange={(e) => handleSettingChange('volume', parseInt(e.target.value))}
                      className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="bg-gray-900 border-t border-gray-700 p-4 flex items-center justify-between">
          <button
            onClick={resetToDefaults}
            className="flex items-center space-x-2 px-4 py-2 text-gray-400 hover:text-white hover:bg-gray-700 rounded-lg transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Reset to Defaults</span>
          </button>
          
          <div className="flex items-center space-x-3">
            <button
              onClick={onClose}
              className="px-4 py-2 text-gray-400 hover:text-white hover:bg-gray-700 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={saveSettings}
              className="flex items-center space-x-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
            >
              <Save className="w-4 h-4" />
              <span>Save Settings</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};