import React, { useState } from 'react';
import { Wifi, WifiOff, Loader2, Settings } from 'lucide-react';
import { XboxConnection, ConnectionStatus } from '../types';

interface ConnectionPanelProps {
  connection: XboxConnection;
  status: ConnectionStatus;
  onConnectionChange: (connection: XboxConnection) => void;
  onConnect: () => void;
  onDisconnect: () => void;
  onOpenSettings: () => void;
  theme: any;
}

export const ConnectionPanel: React.FC<ConnectionPanelProps> = ({
  connection,
  status,
  onConnectionChange,
  onConnect,
  onDisconnect,
  onOpenSettings,
  theme,
}) => {
  const [showSettings, setShowSettings] = useState(false);

  const handleInputChange = (field: keyof XboxConnection, value: string | number) => {
    onConnectionChange({
      ...connection,
      [field]: value,
    });
  };

  return (
    <div className={`${theme.classes.background} border-b ${theme.classes.border} p-4`}>
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            {status.connecting ? (
              <Loader2 className="w-5 h-5 text-blue-400 animate-spin" />
            ) : status.connected ? (
              <Wifi className="w-5 h-5 text-green-400" />
            ) : (
              <WifiOff className="w-5 h-5 text-red-400" />
            )}
            <span className={`${theme.classes.text} font-medium`}>
              {status.connecting ? 'Connecting...' : status.connected ? 'Connected' : 'Disconnected'}
            </span>
          </div>
          
          {status.connected && (
            <span className={`${theme.classes.textSecondary} text-sm`}>
              {connection.username}@{connection.ip}:{connection.port}
            </span>
          )}
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={onOpenSettings}
            className={`p-2 ${theme.classes.textSecondary} hover:${theme.classes.text} ${theme.classes.surfaceHover} rounded-lg transition-colors`}
          >
            <Settings className="w-4 h-4" />
          </button>

          <button
            onClick={() => setShowSettings(!showSettings)}
            className={`p-2 ${theme.classes.textSecondary} hover:${theme.classes.text} ${theme.classes.surfaceHover} rounded-lg transition-colors`}
          >
            <Settings className="w-4 h-4" />
          </button>
          
          {status.connected ? (
            <button
              onClick={onDisconnect}
              className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-medium transition-colors"
            >
              Disconnect
            </button>
          ) : (
            <button
              onClick={onConnect}
              disabled={status.connecting || !connection.ip}
              className={`px-4 py-2 ${theme.classes.primary} ${theme.classes.primaryHover} disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded-lg font-medium transition-colors`}
            >
              Connect
            </button>
          )}
        </div>
      </div>

      {status.error && (
        <div className="mt-3 p-3 bg-red-900/50 border border-red-700 rounded-lg">
          <p className="text-red-200 text-sm">{status.error}</p>
        </div>
      )}

      {showSettings && (
        <div className={`mt-4 p-4 ${theme.classes.surface} rounded-lg border ${theme.classes.border}`}>
          <h3 className={`${theme.classes.text} font-medium mb-3`}>Connection Settings</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className={`block ${theme.classes.textSecondary} text-sm font-medium mb-1`}>
                Xbox IP Address
              </label>
              <input
                type="text"
                value={connection.ip}
                onChange={(e) => handleInputChange('ip', e.target.value)}
                placeholder="192.168.1.100"
                className={`w-full px-3 py-2 ${theme.classes.surface} border ${theme.classes.border} rounded-lg ${theme.classes.text} placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent`}
              />
            </div>
            <div>
              <label className={`block ${theme.classes.textSecondary} text-sm font-medium mb-1`}>
                Port
              </label>
              <input
                type="number"
                value={connection.port}
                onChange={(e) => handleInputChange('port', parseInt(e.target.value) || 21)}
                className={`w-full px-3 py-2 ${theme.classes.surface} border ${theme.classes.border} rounded-lg ${theme.classes.text} focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent`}
              />
            </div>
            <div>
              <label className={`block ${theme.classes.textSecondary} text-sm font-medium mb-1`}>
                Username
              </label>
              <input
                type="text"
                value={connection.username}
                onChange={(e) => handleInputChange('username', e.target.value)}
                placeholder="xbox"
                className={`w-full px-3 py-2 ${theme.classes.surface} border ${theme.classes.border} rounded-lg ${theme.classes.text} placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent`}
              />
            </div>
            <div>
              <label className={`block ${theme.classes.textSecondary} text-sm font-medium mb-1`}>
                Password
              </label>
              <input
                type="password"
                value={connection.password}
                onChange={(e) => handleInputChange('password', e.target.value)}
                placeholder="xbox"
                className={`w-full px-3 py-2 ${theme.classes.surface} border ${theme.classes.border} rounded-lg ${theme.classes.text} placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent`}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};