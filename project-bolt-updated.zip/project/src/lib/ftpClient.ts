
export async function listXboxFiles(path = '/') {
  try {
    const res = await fetch(`http://localhost:3001/ftp/list?path=${encodeURIComponent(path)}`);
    return await res.json();
  } catch (err) {
    console.error('FTP list failed:', err);
    return [];
  }
}

export async function deleteXboxFile(path) {
  try {
    await fetch(`http://localhost:3001/ftp/delete?path=${encodeURIComponent(path)}`, { method: 'DELETE' });
  } catch (err) {
    console.error('FTP delete failed:', err);
  }
}

export async function downloadXboxFile(path) {
  try {
    const res = await fetch(`http://localhost:3001/ftp/download?path=${encodeURIComponent(path)}`);
    const blob = await res.blob();
    const a = document.createElement('a');
    a.href = window.URL.createObjectURL(blob);
    a.download = path.split('/').pop();
    a.click();
  } catch (err) {
    console.error('FTP download failed:', err);
  }
}

export async function uploadXboxFile(file, targetPath) {
  const formData = new FormData();
  formData.append('file', file);
  formData.append('path', targetPath);

  try {
    const res = await fetch('http://localhost:3001/ftp/upload', {
      method: 'POST',
      body: formData
    });
    return await res.text();
  } catch (err) {
    console.error('FTP upload failed:', err);
  }
}
