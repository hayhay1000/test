
import React, { useState } from 'react';
import { ConnectionPanel } from './components/ConnectionPanel';
import { FileExplorer } from './components/FileExplorer';
import { TransferPanel } from './components/TransferPanel';
import { XboxControlPanel } from './components/XboxControlPanel';
import { SettingsPanel } from './components/SettingsPanel';
import { useXboxConnection } from './hooks/useXboxConnection';
import { useLocalFiles } from './hooks/useLocalFiles';
import { useTheme } from './hooks/useTheme';
import { FileItem, TransferProgress } from './types';
import {
  uploadXboxFile,
  downloadXboxFile,
  deleteXboxFile
} from './lib/ftpClient';

function App() {
  const {
    connection,
    setConnection,
    status,
    xboxFiles,
    xboxPath,
    connect,
    disconnect,
    navigateXbox,
  } = useXboxConnection();

  const { localFiles, localPath, navigateLocal } = useLocalFiles();
  const { currentTheme, theme, changeTheme } = useTheme();

  const [selectedLocalFiles, setSelectedLocalFiles] = useState<FileItem[]>([]);
  const [selectedXboxFiles, setSelectedXboxFiles] = useState<FileItem[]>([]);

  const handleXboxFileSelect = (file: FileItem) => {
    setSelectedXboxFiles([file]);
  };

  const handleXboxFileAction = async (action: string, fileOrBlob: any) => {
    const file = fileOrBlob as FileItem;
    switch (action) {
      case 'upload':
        if (fileOrBlob instanceof File) {
          await uploadXboxFile(fileOrBlob, xboxPath);
          await navigateXbox(xboxPath);
        }
        break;
      case 'download':
        await downloadXboxFile(file.path);
        break;
      case 'delete':
        await deleteXboxFile(file.path);
        await navigateXbox(xboxPath);
        break;
    }
  };

  return (
    <main className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4">
      <ConnectionPanel
        connection={connection}
        setConnection={setConnection}
        status={status}
        onConnect={connect}
        onDisconnect={disconnect}
        theme={theme}
      />
      <SettingsPanel theme={theme} onChangeTheme={changeTheme} />
      <FileExplorer
        title="Local Files"
        files={localFiles}
        currentPath={localPath}
        onNavigate={navigateLocal}
        onFileSelect={(file) => setSelectedLocalFiles([file])}
        onFileAction={() => {}}
        selectedFiles={selectedLocalFiles}
        theme={theme}
      />
      <FileExplorer
        title="Xbox Files"
        files={xboxFiles}
        currentPath={xboxPath}
        onNavigate={navigateXbox}
        onFileSelect={handleXboxFileSelect}
        onFileAction={handleXboxFileAction}
        selectedFiles={selectedXboxFiles}
        isXbox
        theme={theme}
      />
      <TransferPanel />
      <XboxControlPanel />
    </main>
  );
}

export default App;
